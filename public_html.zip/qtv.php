<?php

include 'like_hethong/head.php';
include 'like_hethong/functions.php';
?>


<!DOCTYPE html>
<html lang="vi">
<head>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8" />
    <title>QUẢN TRỊ VIÊN - ĐẠI LÝ - CTV - VIPFBNOW.COM</title>
    <link rel="shortcut icon" href="https://i.imgur.com/h6NWYI8.png">
    <meta property="og:image" content="http://i.imgur.com/JA3DwPC.jpg" />
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />	
 <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>

<div class="row" style="padding-left:15px; padding-right: 15px">
<div class="col-md-12 col-sm-12 col-lg-12">
<div class="alert alert-danger wow flash" style="margin-bottom: 0px">
<span class="h4">
<marquee width="100%" direction="up" behavior="alternate"><marquee direction="right" behavior="alternate"><i class="glyphicon glyphicon-star"></i> QUẢN TRỊ VIÊN - ĐẠI LÝ - CTV - VIPFBNOW.COM <i class="glyphicon glyphicon-star"></i></marquee></marquee></span>
</div>
</div></div></div>
<div class="card panel-body text-center">
              <div class="small-box bg-red"><h2>QUẢN TRỊ VIÊN</h2></div>
                               <div class="col-md-4 ">
          <div class="box box-widget widget-user">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <div class="widget-user-header bg-black" style="background: url('http://vipfbnow.com/theme/img/slv.jpg') center center;">
              <h3 class="widget-user-username"><b class="red">Đỗ Duy Thịnh</b></h3>
              <h5 class="widget-user-desc"><font color="red"><b>NGƯỜI SÁNG LẬP</b></font></h5>
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="https://graph.facebook.com/100006670751625/picture?width=100&amp;height=100">
            </div>
            <div class="box-footer">
                <div class="col-sm-6 border-right">
                  <div class="description-block">
                    <a href="https://www.facebook.com/100006670751625" class="btn btn-success btn-sm"><b><i class="fa fa-fw fa-facebook-square"></i> Profile</b></a>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="description-block">
                    <a href="https://www.facebook.com/messages/t/100006670751625" class="btn btn-danger btn-sm"><b><i class="fa fa-fw fa-envelope-o"></i> Messenger</b></a>
                  </div>
                </div>
              </div>
            </div></div>         
          <!-- lien he 1 -->
        <!-- lien he 2 -->
<div class="col-md-4 ">
          <div class="box box-widget widget-user">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <div class="widget-user-header bg-black" style="background: url('http://vipfbnow.com/theme/img/slv.jpg') center center;">
              <h3 class="widget-user-username"><b class="xanh">TUYỂN</b></h3>
              <h5 class="widget-user-desc"><font color="green Blue"><b>QUẢN TRỊ VIÊN</b></font></h5>
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="https://graph.facebook.com/100006670751625/picture?width=100&amp;height=100">
            </div>
            <div class="box-footer">
                <div class="col-sm-6 border-right">
                  <div class="description-block">
                    <a href="https://www.facebook.com/100006670751625" class="btn btn-success btn-sm"><b><i class="fa fa-fw fa-facebook-square"></i> Profile</b></a>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="description-block">
                    <a href="https://www.facebook.com/messages/t/100006670751625" class="btn btn-danger btn-sm"><b><i class="fa fa-fw fa-envelope-o"></i> Messenger</b></a>
                  </div>
                </div>
              </div>
            </div></div>        
          <!-- lien he 2 -->
        <!-- lien he 3 -->
<div class="col-md-4  ">
          <div class="box box-widget widget-user">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <div class="widget-user-header bg-black" style="background: url('http://vipfbnow.com/theme/img/slv.jpg') center center;">
              <h3 class="widget-user-username"><b class="green">TUYỂN</b></h3>
              <h5 class="widget-user-desc"><font color="green"><b>QUẢN TRỊ VIÊN</b></font></h5>
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="https://graph.facebook.com/100006670751625/picture?width=100&amp;height=100">
            </div>
            <div class="box-footer">
                <div class="col-sm-6 border-right">
                  <div class="description-block">
                    <a href="https://www.facebook.com/100006670751625" class="btn btn-success btn-sm"><b><i class="fa fa-fw fa-facebook-square"></i> Profile</b></a>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="description-block">
                    <a href="https://www.facebook.com/messages/t/100006670751625" class="btn btn-danger btn-sm"><b><i class="fa fa-fw fa-envelope-o"></i> Messenger</b></a>
                  </div>
                </div>
              </div>
            </div></div></div>
<div class="card panel-body text-center">
<div class="small-box bg-aqua"><h2>ĐẠI LÝ</h2></div>
  <div class="col-md-4 ">
          <div class="box box-widget widget-user">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <div class="widget-user-header bg-black" style="background: url('http://vipfbnow.com/theme/img/ctv.jpg') center center;">
              <h3 class="widget-user-username"><b class="xanh">PHẠM MỸ NGA</b></h3>
              <h5 class="widget-user-desc"><font color="xanh"><b>ĐẠI LÝ CẤP I</b></font></h5>
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="https://graph.facebook.com/100012822092259/picture?width=100&amp;height=100">
            </div>
            <div class="box-footer">
                <div class="col-sm-6 border-right">
                  <div class="description-block">
                    <a href="https://www.facebook.com/100012822092259" class="btn btn-success btn-sm"><b><i class="fa fa-fw fa-facebook-square"></i> Profile</b></a>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="description-block">
                    <a href="https://www.facebook.com/messages/t/100012822092259" class="btn btn-danger btn-sm"><b><i class="fa fa-fw fa-envelope-o"></i> Messenger</b></a>
                  </div>
                </div>
              </div>
            </div></div>        
          <!-- lien he 2 -->
        <!-- lien he 3 -->
                               <div class="col-md-4 ">
          <div class="box box-widget widget-user">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <div class="widget-user-header bg-black" style="background: url('http://vipfbnow.com/theme/img/ctv.jpg') center center;">
              <h3 class="widget-user-username"><b class="xanh">NGUYỄN VĂN MÃNH</b></h3>
              <h5 class="widget-user-desc"><font color="xanh"><b>ĐẠI LÝ CẤP II</b></font></h5>
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="https://graph.facebook.com/100008630474199/picture?width=100&amp;height=100">
            </div>
            <div class="box-footer">
                <div class="col-sm-6 border-right">
                  <div class="description-block">
                    <a href="https://www.facebook.com/100008630474199" class="btn btn-success btn-sm"><b><i class="fa fa-fw fa-facebook-square"></i> Profile</b></a>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="description-block">
                    <a href="https://www.facebook.com/messages/t/100008630474199" class="btn btn-danger btn-sm"><b><i class="fa fa-fw fa-envelope-o"></i> Messenger</b></a>
                  </div>
                </div>
              </div>
            </div></div>         
          <!-- lien he 1 -->
        <!-- lien he 2 -->
<div class="col-md-4  ">
          <div class="box box-widget widget-user">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <div class="widget-user-header bg-black" style="background: url('http://vipfbnow.com/theme/img/ctv.jpg') center center;">
              <h3 class="widget-user-username"><b class="xanh">TUYỂN</b></h3>
              <h5 class="widget-user-desc"><font color="xanh"><b>ĐẠI LÝ CẤP III</b></font></h5>
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="https://graph.facebook.com/100006670751625/picture?width=100&amp;height=100">
            </div>
            <div class="box-footer">
                <div class="col-sm-6 border-right">
                  <div class="description-block">
                    <a href="https://www.facebook.com/100006670751625" class="btn btn-success btn-sm"><b><i class="fa fa-fw fa-facebook-square"></i> Profile</b></a>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="description-block">
                    <a href="https://www.facebook.com/messages/t/100006670751625" class="btn btn-danger btn-sm"><b><i class="fa fa-fw fa-envelope-o"></i> Messenger</b></a>
                  </div>
                </div>
              </div>
            </div></div> </div> 
<div class="card panel-body text-center">
<div class="small-box bg-green"><h2>CỘNG TÁC VIÊN</h2></div> 	
		 <div class="col-md-4 ">
          <div class="box box-widget widget-user">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <div class="widget-user-header bg-black" style="background: url('http://vipfbnow.com/theme/img/ctv.jpg') center center;">
              <h3 class="widget-user-username"><b class="green">NGUYỄN VĂN HUY</b></h3>
              <h5 class="widget-user-desc"><font color="black"><b>CỘNG TÁC VIÊN</b></font></h5>
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="https://graph.facebook.com/100000221529840/picture?width=100&amp;height=100">
            </div>
            <div class="box-footer">
                <div class="col-sm-6 border-right">
                  <div class="description-block">
                    <a href="https://www.facebook.com/100000221529840" class="btn btn-success btn-sm"><b><i class="fa fa-fw fa-facebook-square"></i> Profile</b></a>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="description-block">
                    <a href="https://www.facebook.com/messages/t/100000221529840" class="btn btn-danger btn-sm"><b><i class="fa fa-fw fa-envelope-o"></i> Messenger</b></a>
                  </div>
                </div>
              </div>
            </div></div>       
          <!-- lien he 1 -->
        <!-- lien he 2 -->
<div class="col-md-4 ">
          <div class="box box-widget widget-user">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <div class="widget-user-header bg-black" style="background: url('http://vipfbnow.com/theme/img/ctv.jpg') center center;">
              <h3 class="widget-user-username"><b class="green">NGUYỄN BẢO NHI</b></h3>
              <h5 class="widget-user-desc"><font color="black"><b>CỘNG TÁC VIÊN</b></font></h5>
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="https://graph.facebook.com/100012147432036/picture?width=100&amp;height=100">
            </div>
            <div class="box-footer">
                <div class="col-sm-6 border-right">
                  <div class="description-block">
                    <a href="https://www.facebook.com/100012147432036" class="btn btn-success btn-sm"><b><i class="fa fa-fw fa-facebook-square"></i> Profile</b></a>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="description-block">
                    <a href="https://www.facebook.com/messages/t/100012147432036" class="btn btn-danger btn-sm"><b><i class="fa fa-fw fa-envelope-o"></i> Messenger</b></a>
                  </div>
                </div>
              </div>
            </div></div>       
          <!-- lien he 2 -->
        <!-- lien he 3 -->
<div class="col-md-4  ">
          <div class="box box-widget widget-user">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <div class="widget-user-header bg-black" style="background: url('http://vipfbnow.com/theme/img/ctv.jpg') center center;">
              <h3 class="widget-user-username"><b class="green">NGUYỄN THỊ LÂM</b></h3>
              <h5 class="widget-user-desc"><font color="black"><b>CỘNG TÁC VIÊN</b></font></h5>
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="https://graph.facebook.com/100014652669775/picture?width=100&amp;height=100">
            </div>
            <div class="box-footer">
                <div class="col-sm-6 border-right">
                  <div class="description-block">
                    <a href="https://www.facebook.com/100014652669775" class="btn btn-success btn-sm"><b><i class="fa fa-fw fa-facebook-square"></i> Profile</b></a>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="description-block">
                    <a href="https://www.facebook.com/messages/t/100014652669775" class="btn btn-danger btn-sm"><b><i class="fa fa-fw fa-envelope-o"></i> Messenger</b></a>
                  </div>
                </div>
              </div>
            </div></div> 
			 <div class="col-md-4 ">
          <div class="box box-widget widget-user">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <div class="widget-user-header bg-black" style="background: url('http://vipfbnow.com/theme/img/ctv.jpg') center center;">
              <h3 class="widget-user-username"><b class="green">LONG VU</b></h3>
              <h5 class="widget-user-desc"><font color="black"><b>CỘNG TÁC VIÊN</b></font></h5>
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="https://graph.facebook.com/100004926879608/picture?width=100&amp;height=100">
            </div>
            <div class="box-footer">
                <div class="col-sm-6 border-right">
                  <div class="description-block">
                    <a href="https://www.facebook.com/100004926879608" class="btn btn-success btn-sm"><b><i class="fa fa-fw fa-facebook-square"></i> Profile</b></a>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="description-block">
                    <a href="https://www.facebook.com/messages/t/100004926879608" class="btn btn-danger btn-sm"><b><i class="fa fa-fw fa-envelope-o"></i> Messenger</b></a>
                  </div>
                </div>
              </div>
            </div></div>       
          <!-- lien he 1 -->
        <!-- lien he 2 -->
<div class="col-md-4 ">
          <div class="box box-widget widget-user">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <div class="widget-user-header bg-black" style="background: url('http://vipfbnow.com/theme/img/ctv.jpg') center center;">
              <h3 class="widget-user-username"><b class="green">TUYỂN</b></h3>
              <h5 class="widget-user-desc"><font color="black"><b>CỘNG TÁC VIÊN</b></font></h5>
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="https://graph.facebook.com/100006670751625/picture?width=100&amp;height=100">
            </div>
            <div class="box-footer">
                <div class="col-sm-6 border-right">
                  <div class="description-block">
                    <a href="https://www.facebook.com/100006670751625" class="btn btn-success btn-sm"><b><i class="fa fa-fw fa-facebook-square"></i> Profile</b></a>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="description-block">
                    <a href="https://www.facebook.com/messages/t/100006670751625" class="btn btn-danger btn-sm"><b><i class="fa fa-fw fa-envelope-o"></i> Messenger</b></a>
                  </div>
                </div>
              </div>
            </div></div>       
          <!-- lien he 2 -->
        <!-- lien he 3 -->
<div class="col-md-4  ">
          <div class="box box-widget widget-user">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <div class="widget-user-header bg-black" style="background: url('http://vipfbnow.com/theme/img/ctv.jpg') center center;">
              <h3 class="widget-user-username"><b class="green">TUYỂN</b></h3>
              <h5 class="widget-user-desc"><font color="black"><b>CỘNG TÁC VIÊN</b></font></h5>
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="https://graph.facebook.com/100006670751625/picture?width=100&amp;height=100">
            </div>
            <div class="box-footer">
                <div class="col-sm-6 border-right">
                  <div class="description-block">
                    <a href="https://www.facebook.com/100006670751625" class="btn btn-success btn-sm"><b><i class="fa fa-fw fa-facebook-square"></i> Profile</b></a>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="description-block">
                    <a href="https://www.facebook.com/messages/t/100006670751625" class="btn btn-danger btn-sm"><b><i class="fa fa-fw fa-envelope-o"></i> Messenger</b></a>
                  </div>
                </div>
              </div>
            </div></div> 
</div>

<?php
include 'like_hethong/foot.php';
?>
