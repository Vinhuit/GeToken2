<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo $home ?>/theme/toastr.css">        
        <link rel="stylesheet" href="<?php echo $home ?>/theme/dataTables.bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo $home ?>/theme/stuly.css">
 <link rel="stylesheet" href="<?php echo $home ?>/theme/pace.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo $home; ?>/theme/dist/sweetalert.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
 <script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
