<?php
include 'like_hethong/head.php';
include '../theme/css.php';
include 'checkidfb.php';
include 'like_hethong/foot.php';
?>