
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />

<div class="col-sm-12">
<div class="alert alert-danger">
<center>
<b style="color:white"><h3>TÀI KHOẢN CHƯA ĐƯỢC KÍCH HOẠT</h3></b></center>
</div></div>
<div class="col-sm-6">
                <div class="panel panel-default">
                   <div class="panel-heading">
<i class="fa fa-cogs"></i><b> HƯỚNG DẪN KÍCH HOẠT</b>
</div>
<div class="panel-body">
<div class="alert alert-success">
      <strong>CÁCH KÍCH HOẠT BẰNG EMAIL</strong>
    <ul>
        <li>
          Sau khi đăng ký thành công bạn chúng tôi đã gửi 1 mail kích hoạt.
        </li>
        <li>
         B1: Vào mail kiểm tra mail trong <b>Hòm Thư hoặc Thư Rác (Spam)</b>.
        </li>
        <li>
         B2: Sau đó click vào liên kết trong mail để xác minh
        </li>
    </ul>
</div>
<div class="alert alert-success">
      <strong><i class="fa fa-fw fa-retweet"></i> CÁCH KÍCH HOẠT BẰNG NẠP THẺ</strong>
    <ul>
        <li>
          Sau khi đăng ký thành công , bạn nạp tiền vào tài khoản với số tiền bất kỳ <b>Tài khoản của bạn sẽ được kích hoạt ngay</b>
        </li>
        <li>MỌI THẮC MẮC VUI LÒNG LIÊN HỆ ADMIN NHÉ</li>
    </ul>
</div>
<div class="alert alert-danger">
<li><b>TÀI KHOẢN SẼ BỊ XÓA SAU 1 GIỜ NẾU KHÔNG KÍCH HOẠT ĐỂ TRÁNH TÌNH TRẠNG SPAM ĐĂNG KÝ TÀI KHOẢN NHẰM MỤC ĐÍCH KHÁC</b></li>
</div>
</div></div>
</div>
